package es.uco.pw.factory.example;

/**
 * The abstract product in the factory example
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public abstract class Meal {

	/** Name of the meal */
	protected String name;
	
	/** Cost of the meal */
	protected double price;

	public Meal(String name, double price) {
		this.name = name;
		this.price = price;
	}
	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return this.price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
	public String toString() {
		String info = "Name: " + this.name + " Price: " + this.price;
		return info;
	}
}
