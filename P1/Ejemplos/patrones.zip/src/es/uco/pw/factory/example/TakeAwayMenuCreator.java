package es.uco.pw.factory.example;

import java.util.ArrayList;

/**
 * The concrete factory that creates food menus to take away
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class TakeAwayMenuCreator extends MenuCreator{

	@Override
	public ArrayList<DailyMeal> createWeekMenu() {
		ArrayList<DailyMeal> takeAwayMenu = new ArrayList<DailyMeal>();
		DailyMeal firstDish = new DailyMeal("ensalada", 1.5);
		firstDish.setType(Type.entrante);
		
		DailyMeal secondDish = new DailyMeal("brocheta", 4);
		secondDish.setGarnish("patatas");
		secondDish.setType(Type.principal);		
		
		takeAwayMenu.add(firstDish);
		takeAwayMenu.add(secondDish);
		
		return takeAwayMenu;
	}

	@Override
	public SeasonMeal createSeasonMenu() {
		SeasonMeal dish = new SeasonMeal("alcachofas a la montillana", 3.75);
		dish.setSeason(Season.invierno);
		dish.setExtraCost(1);
		return dish;
	}
}
