package es.uco.pw.factory;

/**
 * The definition of the abstract factory
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public abstract class AbstractFactory {

	// Factory methods for each product
	
	public abstract ProductA createProductA();
	
	public abstract ProductB createProductB();
}
