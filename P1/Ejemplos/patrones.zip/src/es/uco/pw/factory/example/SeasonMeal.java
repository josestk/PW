package es.uco.pw.factory.example;

/**
 * A concrete product in the factory example 
 * that is only available in some seasons
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class SeasonMeal extends Meal {

	/** The season when this meal can be offered */
	private Season season;
	
	/** The extra cost to be added to the price */
	private int extraCost;
	
	public SeasonMeal(String name, double price) {
		super(name, price);
		this.extraCost = 0;
	}

	public Season getSeason() {
		return this.season;
	}

	public void setSeason(Season season) {
		this.season = season;
	}

	public int getExtraCost() {
		return this.extraCost;
	}

	public void setExtraCost(int extraCost) {
		this.extraCost = extraCost;
	}
	
	public String toString() {
		String info = "Name: " + this.name + " Price: " + (this.price+this.extraCost);
		if(this.season!=null)
			info += " Season: " + this.season;
		return info;
	}
}
