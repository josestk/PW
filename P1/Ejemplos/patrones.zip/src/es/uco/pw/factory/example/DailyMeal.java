package es.uco.pw.factory.example;

/**
 * A concrete product in the factory example
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class DailyMeal extends Meal{

	/** Type of dish (see Type enumeration) */
	private Type type;
	
	/** Side dish */
	private String garnish;
	
	public DailyMeal(String name, double price) {
		super(name, price);
	}

	public Type getType() {
		return type;
	}

	public void setType(Type type) {
		this.type = type;
	}

	public String getGarnish() {
		return garnish;
	}

	public void setGarnish(String garnish) {
		this.garnish = garnish;
	}	
	
	public String toString() {
		String info = super.toString();
		if(this.type!=null)
			info += " Type: " + this.type;
		if(this.garnish != null)
			info += " Served with: " + this.garnish;
		return info;
	}
}
