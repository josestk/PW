package es.uco.pw.factory;

/**
 * A concrete product in the hierarchy of products
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ProductB extends AbstractProduct {

	// Specific properties of ProductB
	
	public ProductB() {
		
	}
	
	public ProductB(int id) {
		this.id = id;
	}
	
	// Specific methods of ProductB
}
