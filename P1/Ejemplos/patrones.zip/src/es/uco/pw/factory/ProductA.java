package es.uco.pw.factory;

/**
 * A concrete product in the hierarchy of products
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ProductA extends AbstractProduct {

	// Specific properties of ProductA
	
	public ProductA() {
		
	}
	
	public ProductA(int id) {
		this.id = id;
	}
	
	// Specific methods of ProductA
}
