package es.uco.pw.factory.example;

import java.util.ArrayList;

/**
 * A main program to run the factory example
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class FactoryMainProgram {

	public static void main(String[] args) {
		
		RestaurantMenuCreator restaurantFactory = new RestaurantMenuCreator();
		ArrayList<DailyMeal> menu = restaurantFactory.createWeekMenu();
		System.out.println("Menu for this week at the restaurant:");
		for(DailyMeal m: menu) {
			System.out.println("\t" + m);
		}
		
		System.out.println("And for take away:");
		TakeAwayMenuCreator takeAwayFactory = new TakeAwayMenuCreator();
		SeasonMeal thisWeekOffer = takeAwayFactory.createSeasonMenu();
		System.out.println("\t" + thisWeekOffer);
	}

}
