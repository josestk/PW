package es.uco.pw.factory;

/**
 * A concrete factory that creates products without properties
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ConcreteFactory2 extends AbstractFactory {

	// Implementation of creation methods
	
	@Override
	public ProductA createProductA() {
		ProductA product = new ProductA();
		return product;
	}

	@Override
	public ProductB createProductB() {
		ProductB product = new ProductB();
		return product;
	}
}
