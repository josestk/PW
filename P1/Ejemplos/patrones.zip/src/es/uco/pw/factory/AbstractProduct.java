package es.uco.pw.factory;

/**
 * The abstract class that represent a general product
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public abstract class AbstractProduct {

	// Common properties of all products
	
	protected int id;
	
}
