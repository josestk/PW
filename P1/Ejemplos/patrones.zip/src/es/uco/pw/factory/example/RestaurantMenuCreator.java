package es.uco.pw.factory.example;

import java.util.ArrayList;

/**
 * The concrete factory that creates food menus for
 * clients at a restaurant.
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class RestaurantMenuCreator extends MenuCreator{

	@Override
	public ArrayList<DailyMeal> createWeekMenu() {
		ArrayList<DailyMeal> weekMenu = new ArrayList<DailyMeal>();
		DailyMeal firstDish = new DailyMeal("salmorejo", 2.25);
		firstDish.setType(Type.entrante);
		
		DailyMeal secondDish = new DailyMeal("churrasco", 6);
		secondDish.setGarnish("ensalada");
		secondDish.setType(Type.principal);	
		
		DailyMeal dessert = new DailyMeal("flan", 4.75);
		dessert.setType(Type.postre);
		
		weekMenu.add(firstDish);
		weekMenu.add(secondDish);
		weekMenu.add(dessert);
		return weekMenu;
	}

	@Override
	public SeasonMeal createSeasonMenu() {
		SeasonMeal dish = new SeasonMeal("alcachofas a la montillana", 3.75);
		dish.setSeason(Season.invierno);
		dish.setExtraCost(0);
		return dish;
	}
}
