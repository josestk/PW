package es.uco.pw.factory.example;

/**
 * An enumeration with the type of dish
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public enum Type {
	entrante,
	principal,
	postre
}
