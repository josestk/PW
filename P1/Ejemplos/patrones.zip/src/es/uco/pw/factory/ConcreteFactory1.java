package es.uco.pw.factory;

/**
 * A concrete factory that creates products with certain properties
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ConcreteFactory1 extends AbstractFactory {

	// Implementation of creation methods
	
	@Override
	public ProductA createProductA() {
		ProductA product = new ProductA(0);
		return product;
	}

	@Override
	public ProductB createProductB() {
		ProductB product = new ProductB(1);
		return product;
	}

}
