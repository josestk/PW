package es.uco.pw.factory.example;

/**
 * An enumeration with the four seasons
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */
public enum Season {
	primavera,
	verano,
	otono,
	invierno
}
