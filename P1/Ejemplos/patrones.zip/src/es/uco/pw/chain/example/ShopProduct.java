package es.uco.pw.chain.example;

/**
 * The product that can be sold by shops
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ShopProduct {

	/** Name of the product */
	private String name;
	
	/** Number of units available */
	private int units;

	public ShopProduct(String name, int units) {
		this.name = name;
		this.units = units;
	}
	
	public String getName() {
		return this.name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getUnits() {
		return this.units;
	}

	public void setUnits(int units) {
		this.units = units;
	}
	
	public boolean isAvailable() {
		if(this.units > 0) {
			return true;
		}
		return false;
	}
	
	public void addUnit() {
		this.units++;
	}
	
	public void sellUnit() {
		this.units--;
	}
	
}
