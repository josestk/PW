package es.uco.pw.chain.example;

/**
 * The main program to show how the chain of responsibility works
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class ChainMainProgram {

	public static void main(String[] args) {
		
		LocalShop cordobaShop = new LocalShop();
		cordobaShop.setSuccessor(new NationalShop());

		// First client wants a jeans
		System.out.println("Client 1 wants to buy a jeans...");
		boolean canBuy = cordobaShop.findProduct("jeans");
		System.out.println("Client 1 finds product: " + canBuy);
		
		// Second client wants a t-shirt
		System.out.println("Client 2 wants to buy a t-shirt...");
		canBuy = cordobaShop.findProduct("t-shirt");
		System.out.println("Client 2 finds product: " + canBuy);
		
		// Third client wants a jeans
		System.out.println("Client 3 wants to buy a jeans...");
		canBuy = cordobaShop.findProduct("jeans");
		System.out.println("Client 3 finds product: " + canBuy);
		
		// Last client wants a jacket
		System.out.println("Client 4 wants to buy a jacket...");
		canBuy = cordobaShop.findProduct("jacket");
		System.out.println("Client 4 finds product: " + canBuy);
		
	}

}
