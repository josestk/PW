package es.uco.pw.chain;

/**
 * A concrete handler of the chain of responsibility
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class SecondHandler extends AbstractHandler{

	public SecondHandler() {
		this.successor = new LastHandler(); // or use setSucessor in the client
	}
	
	@Override
	public void handleRequest(Request request) {
		if(request.getType() == 1) {
			// do something
		}
		else if(this.successor != null){
			this.successor.handleRequest(request);
		}
		
	}

}
