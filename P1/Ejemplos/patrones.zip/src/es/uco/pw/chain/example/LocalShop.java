package es.uco.pw.chain.example;

import java.util.ArrayList;

/**
 * A local shop to handle request of products in stock
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class LocalShop extends StockProvider {

	/** The list of currently available products */
	private ArrayList<ShopProduct> productsInStock;
	
	public LocalShop() {
		this.productsInStock = new ArrayList<ShopProduct>();
		this.createStock();
	}
	
	@Override
	public boolean findProduct(String productName) {
		
		boolean inStock = false;
		int size = this.productsInStock.size();
		for(int i=0; !inStock && i<size; i++) {
			ShopProduct p = this.productsInStock.get(i);
			if(p.getName().equals(productName) && p.isAvailable()) {
				inStock = true;
				p.sellUnit();
				System.out.println("Product found in local shop");
			}
		}
		if(!inStock) {
			System.out.println("Product not found in local shop, ask next supplier");
			inStock = this.nextProvider.findProduct(productName);
		}
		return inStock;
	}
	
	/**
	 * Initialize some products in stock
	 * */
	private void createStock() {
		this.productsInStock.add(new ShopProduct("t-shirt", 0));
		this.productsInStock.add(new ShopProduct("jeans", 1));
		this.productsInStock.add(new ShopProduct("jacket", 0));
	}

}
