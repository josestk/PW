package es.uco.pw.chain;

public class Request {
	// The object to be processed by the chain
	
	public int type;

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}
	
	
}
