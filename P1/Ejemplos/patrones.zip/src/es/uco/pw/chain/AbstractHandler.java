package es.uco.pw.chain;

/**
 * The abstract handler of the chain of responsibility
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public abstract class AbstractHandler {

	// The next handler in the chain
	protected AbstractHandler successor;
	
	// 1 - A method to assign the successor (build the chain in the client)
	public void setSuccessor(AbstractHandler succesor) {
		this.successor = succesor;
	}
	
	// 2 - An abstract method to handle the request 
	public abstract void handleRequest(Request request);
	
}
