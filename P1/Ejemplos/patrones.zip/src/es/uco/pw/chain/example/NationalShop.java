package es.uco.pw.chain.example;

import java.util.ArrayList;

/**
 * A concrete handler in the chain that represents a shop
 * with two stocks.
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class NationalShop extends StockProvider {

	/** The national provider has two stocks */
	private ArrayList<ShopProduct> productsInStockMadrid;

	private ArrayList<ShopProduct> productsInStockBarcelona;

	public NationalShop() {
		this.productsInStockMadrid = new ArrayList<ShopProduct>();
		this.productsInStockBarcelona = new ArrayList<ShopProduct>();
		this.createStocks();
	}

	@Override
	public boolean findProduct(String productName) {
		boolean inStock = false;

		// Firstly, try in Madrid
		inStock = findProductInStock(this.productsInStockMadrid, productName);

		if(inStock) {
			System.out.println("Product found in Madrid");
		}
		else{
			// Try in Barcelona
			inStock = findProductInStock(this.productsInStockBarcelona, productName);
			if(inStock) {
				System.out.println("Product found in Barcelona");
			}
			else { // end of the chain
				System.out.println("Product not found");
			}
		}

		return inStock;
	}

	/**
	 * Initialize some products in stock
	 * */
	private void createStocks() {
		this.productsInStockMadrid.add(new ShopProduct("t-shirt", 4));
		this.productsInStockMadrid.add(new ShopProduct("jeans", 0));

		this.productsInStockBarcelona.add(new ShopProduct("jacket", 0));
		this.productsInStockBarcelona.add(new ShopProduct("jeans", 1));
	}

	/**
	 * Find a product in a given stock
	 * */
	private boolean findProductInStock(ArrayList<ShopProduct> stockCity, String productName) {
		int size = stockCity.size();
		boolean inStock = false;
		for(int i=0; !inStock && i<size; i++) {
			ShopProduct p = stockCity.get(i);
			if(p.getName().equals(productName) && p.isAvailable()) {
				inStock = true;
				p.sellUnit();
			}
		}
		return inStock;
	}

}
