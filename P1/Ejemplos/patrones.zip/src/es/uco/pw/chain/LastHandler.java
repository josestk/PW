package es.uco.pw.chain;

/**
 * A concrete handler of the chain of responsibility without successor
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class LastHandler extends AbstractHandler {

	public LastHandler() {
		this.successor = null;
	}
	
	@Override
	public void handleRequest(Request request) {
		if(request.getType() == 2) {
			// do something
		}
		// actually the chain ends here...
		else if(this.successor != null){
			this.successor.handleRequest(request);
		}

	}

}
