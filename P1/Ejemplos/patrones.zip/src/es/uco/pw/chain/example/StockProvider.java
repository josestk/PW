package es.uco.pw.chain.example;

/**
 * The abstract class to build the chain of shops and find products in stock
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public abstract class StockProvider {

	/** Another stock provider to ask for
	 * a product when it is not available  */
	protected StockProvider nextProvider;
		
	/**
	 * Set successor
	 * */
	public void setSuccessor(StockProvider succesor) {
			this.nextProvider = succesor;
	}
		
	/**
	 * Handle the purchase
	 * */
	public abstract boolean findProduct(String productName);
	
}
