package es.uco.pw.singleton.example;

/**
 * A main program to show the use of the singleton example
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class SingletonMainProgram {

	public static void main(String[] args) {
		
		RandomSequence seq1 = RandomSequence.getInstance();
		System.out.println("Singleton instance reference: " + seq1);
		for(int i=0; i<5; i++) {
			System.out.println(seq1.nextRandomValue());
		}
		
		RandomSequence seq2 = RandomSequence.getInstance();
		System.out.println(seq2.equals(seq1));
	}

}
