package es.uco.pw.singleton;

/**
 * A singleton class
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class Singleton {

	// 1 - One unique instance
	
	private static Singleton instance = null;
	
	// 2 - Private constructor
	
	private Singleton() {

	}
	
	// 3 - Access point to the instance
	
	public static Singleton getInstance() {
		if(instance == null) {
			instance = new Singleton();
		}
		return instance;
	}
}
