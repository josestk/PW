package es.uco.pw.singleton.example;

import java.util.Random;

/**
 * A random number generator implementing the singleton pattern
 * @author Aurora Ramirez
 * @author Jose Raul Romero
 * */

public class RandomSequence {

	// 1 - The singleton

	private static RandomSequence instance = null;

	// Other properties
	private Random rndObject;
	
	// 2 - Private constructor

	private RandomSequence() {
		this.rndObject = new Random(0);
	}

	// 3 - Access point to the instance

	public static RandomSequence getInstance() {
		if(instance == null) {
			instance = new RandomSequence();
		}
		return instance;
	}
	
	// Other operations within the class
	public Integer nextRandomValue() {
		if(instance != null) {
			Integer rndValue = Integer.valueOf(this.rndObject.nextInt());
			return rndValue;
		}
		return null;
	}
}
