Para la ejecucion de los programas (contactop1.jar y tablonp1.jar) copie la ruta del fichero llamado "contactos.properties" e introduzcala entre comillas como argumento al ejercutar el programa.
Ej: java -jar contacto.jar "C:\Users\PW\P1(jdk1.8)\contactos.properties"

Para la eleccion de intereses se deben elegir alguno de los siguientes, no siendo posible el uso de cualquier otro.
Intereses: moda,fitness,videojuegos,deporte,cine,series,arquitectura,baile,musica,deportes.