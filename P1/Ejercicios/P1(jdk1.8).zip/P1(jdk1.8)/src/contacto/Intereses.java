package contacto;

/**
 * Enum with interests 
 * @author Carlos Revuelto Quero
 * @author Jose Antonio Gonzalez Aguilera
 */
public enum Intereses {
	
	VACIO,
	moda,
	fitness,
	videojuegos,
	deporte,
	cine,
	series,
	arquitectura,
	baile,
	musica,
	deportes,
	
}
