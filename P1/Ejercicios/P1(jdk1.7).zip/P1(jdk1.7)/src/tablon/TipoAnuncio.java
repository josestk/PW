package tablon;


/**
 * An enumeration with the values of the field TipoAnuncio
 * @author Carlos Revuelto
 * @author Jose Antonio Gonz�lez
 */
public enum TipoAnuncio {
	
	general,
	tematico,
	individualizado,
	flash
	
}

